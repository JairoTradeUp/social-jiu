# Relatório de Estado e Contexto do Projeto: **Social Jiu**

Este relatório consolida o estado atual do desenvolvimento do protótipo de alta fidelidade do **Social Jiu** — uma rede social mobile-first voltada para praticantes de Brazilian Jiu-Jitsu (BJJ). O principal objetivo deste documento é permitir a restauração imediata do contexto de desenvolvimento e memória técnica em qualquer outra estação de trabalho.

---

## 🛠️ Stack Tecnológica & Dependências

* **Core:** React 18 (com JSX) + Vite 8
* **Styling (CSS):** Tailwind CSS v3.4.x (via PostCSS)
  * > [!IMPORTANT]
  * > **NÃO utilize nem atualize para Tailwind v4.** As tentativas de usar `@tailwindcss/vite` (v4) falharam anteriormente na geração de CSS compilado. O setup atual depende de `postcss.config.js` e das diretivas do Tailwind no arquivo `src/index.css` que são processadas corretamente pelo Vite.
* **Roteamento:** React Router v7
* **Animações & Transições:** Framer Motion v12
* **Ícones:** Lucide React
* **Fundo de Dados:** Mock data 100% client-side via React Context API (`AppContext.jsx` + `mockData.js`). Sem infraestrutura de backend.

---

## 📐 Design System & Tokens Coletados

O design do aplicativo é baseado em um modelo móvel padrão de **390px** de largura (Viewport Mobile-First, centralizado globalmente com margens automáticas).

### 🎨 Paleta de Cores (Definida no Tailwind)
* **Brand Colors:**
  * Vermelho BJJ: `brand-red` (`#C0203A`)
  * Vermelho Escuro: `brand-red-dark` (`#9A1830`)
  * Azul BJJ: `brand-blue` (`#2B5FAC`)
  * Azul Escuro: `brand-blue-dark` (`#1E3F6F`)
  * Marinho Base: `brand-navy` (`#1B2A4A`)
* **Surfaces (Superfícies Dark Mode):**
  * Fundo Geral: `surface-bg` (`#0F0F0F`)
  * Cards: `surface-card` (`#1A1A1A`)
  * Elemento Elevado: `surface-elevated` (`#222222`)
  * Borda Base: `surface-border` (`#2A2A2A`)
  * Borda Destacada: `surface-border-2` (`#3A3A3A`)
* **Tipografia:** Fonte **Red Hat Display** (pesos 400, 500, 600, 700) carregada diretamente via HTML Header para otimização de renderização.

### 🥋 Definição das Faixas (Belts)
As cores das faixas dos usuários influenciam diretamente nos badges visuais e em bordas de destaques:
* **Branca:** Fundo `#FFFFFF` | Texto `#0F0F0F`
* **Azul:** Fundo `#2B5FAC` | Texto `#FFFFFF`
* **Roxa:** Fundo `#7B3FA0` | Texto `#FFFFFF`
* **Marrom:** Fundo `#7B4A2D` | Texto `#FFFFFF`
* **Preta:** Fundo `#1A1A1A` | Texto `#FFFFFF`
* **Coral:** Fundo `#C0203A` | Texto `#FFFFFF`

---

## 📂 Arquitetura e Módulos Implementados

O código está estruturado em uma arquitetura modularizada, separando responsabilidades por contexto de negócio no diretório `src/modules/`.

```
src/
├── App.jsx                           # Roteador central e AnimatePresence
├── main.jsx                          # Provedor global e renderização
├── index.css                         # Diretivas do Tailwind e resets globais
├── context/
│   └── AppContext.jsx                # Estado global (likes, follows, bookmarks, auth, chats)
├── data/
│   └── mockData.js                   # Mock data massivo para feed, usuários e conversas
├── components/
│   ├── ui/                           # Componentes reutilizáveis básicos (Button, Input, Avatar, Badge, ProgressBar)
│   └── layout/                       # Peças fixas do layout (StatusBar, TopBar, BottomNav)
└── modules/                          # Módulos de tela por funcionalidade
```

### Detalhamento dos Módulos:
1. **`auth` (Autenticação e Onboarding):**
   * Fluxo de Login, Cadastro, Recuperação de Senha.
   * Processo de Onboarding interativo em 5 etapas para novos praticantes: Escolha de Faixa 🥋, Seleção de Academia 🏢, Interesses/Estilo de Luta 🤼‍♂️, Sugestão de Usuários parceiros e Conclusão.
2. **`feed` (Módulo Principal):**
   * Exibição de postagens, stories dinâmicos, curtidas e salvamento de posts.
   * Visualização dedicada de comentários com transição vertical tipo bottom-sheet.
3. **`explore` (Módulo de Descoberta):**
   * Tela para busca de novos usuários, academias próximas e conteúdos em alta.
4. **`connections` (Parcerias e Rede):**
   * Gestão de conexões, praticantes próximos e sugestões de treino ("rolê").
5. **`circles` (Círculos / Grupos):**
   * Criação e visualização de grupos de treino, discussão ou focados em equipes específicas.
6. **`messages` (Chat e Comunicação):**
   * Canal direto de mensagens privadas (DMs) com histórico de conversas e tela de chat ativa.
7. **`notifications` (Notificações):**
   * Feed de atividades contendo novos seguidores, curtidas, comentários e menções de treino.
8. **`profile` (Perfil do Usuário):**
   * Perfil completo com listagem de posts do atleta, galeria de fotos, edição de dados, configurações e listagem de seguidores/seguindo.

---

## 🔄 Estado Atual das Últimas Modificações

* **Expandindo o Protótipo:** Nas últimas implementações, o escopo foi expandido de forma expressiva com a inclusão e integração total no roteador dos módulos de **Explore**, **Connections**, **Circles**, **Chat (Messages)** e **Notifications**.
* **Modificações Locais Ativas (Staged changes):**
  * `src/modules/auth/SplashScreen.jsx` foi otimizado para substituir as iniciais de texto estilizadas por uma imagem de logo centralizada (`/assets/logo-social-jiu.png`) com animação suave de scale contínuo em formato pulso (`scale: [1, 1.05, 1]`) facilitando o visual premium logo na inicialização.

---

## 🚀 Guia de Inicialização Rápida para Outra Estação

1. **Instalar dependências (sem atualizar pacotes cruciais):**
   ```bash
   npm install
   ```
2. **Executar o ambiente de desenvolvimento local:**
   ```bash
   npm run dev
   ```
   * O aplicativo estará disponível em: `http://localhost:5173`
3. **Credenciais para testes de fluxos:**
   * **E-mail de teste padrão:** `rafael@email.com`
   * **Senha:** Qualquer senha (mínimo de 6 caracteres).
   * *Dica:* O login direciona por padrão para o fluxo de Onboarding. Caso precise ir direto para a tela principal de conteúdos, utilize a rota `/feed` diretamente no navegador.
